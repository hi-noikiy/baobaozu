<?php defined('SYSTEM_IN') or exit('Access Denied');?>
<?php include page("system_header");?>
     <form  method="post" class="form-horizontal form">
 <div class="panel ">
        <h3 class="custom_page_header">   授权许可   </h3>
       	<div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 control-label"></label>
                    <div class="col-sm-9 col-xs-12">
                       
                   
                     
                    </div>
                </div>
       	<div class="form-group" >
       		   <div align="center" style="width:90%;margin:0 auto;">
       		     <h4>   如果您使用本软件，即表示您同意并愿意遵循以下协议内容：   </h4></div>
                       <div align="center" style="width:90%;margin:0 auto;">
			 <textarea name="license" class="form-control richtext" readonly="true" cols="70" rows="15" style="overflow:auto;width:100%;">使用该许可证的软件被授予以下权限，免费，任何人可以得到这个软件及其相关文档的一个拷贝，并且经营该软件不受任何限制，包括无限制的使用、复制、修改、合并、出版、发行、发放从属证书、或者出售该软件的拷贝的权利。
    该软件按本来的样子提供，没有任何形式的担保，不管是明确地或者暗含的，包含这些但是不受商业性质的担保的限制。适合一个特定的用途并且不受侵犯。福州百家威信信息技术有限责任公司在任何场合对使用该软件涉及的任何要求、损害或者其他责任都不应负责。不管它是正在起作用还是只是合同形式、民事侵权或是其他方式，如由它引起，在其作用范围内、与该软件有联系、该软件的使用或者有这个软件引起的其他行为。
有限担保和免责声明：
    1、本软件及所附带的文件是作为不提供任何明确的或隐含的赔偿或担保的形式提供的。
    2、用户出于自愿而使用本软件，您必须了解使用本软件的风险，在尚未购买产品技术服务之前，我们不承诺对免费用户提供任何形式的技术支持、使用担保，也不承担任何因使用本软件而产生问题的相关责任。
    ​3、电子文本形式的授权协议如同双方书面签署的协议一样，具有完全的和等同的法律效力。您一旦开始确认本协议并安装本程序，即被视为完全理解并接受本协议的各项条款，在享有上述条款授予的权力的同时，受到相关的约束和限制。协议许可范围以外的行为，将直接违反本授权协议并构成侵权，我们有权随时终止授权，责令停止损害，并保留追究相关责任的权力。
    ​4、本合同最终解释权归福州百家威信信息技术有限责任公司所有。
			 	</textarea>
      </div
            </div>
        </div>
 </div>
</form>
<?php include page("footer-base");?>