<?php 
	include page('license');